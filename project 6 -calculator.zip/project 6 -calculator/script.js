let inputscreen = document.getElementById("inputbox");
let buttons = document.querySelectorAll(".btn-container button");
let string = "";

buttons.forEach(button => {
    button.addEventListener("click", () => {
        let buttonvalue = button.textContent;
     if ( buttonvalue=== "AC"){
            string = "";
            inputscreen.value = "0"             
        }

        else if(buttonvalue== "DEL"){
            string = string.slice(0 , -1) || "0";
            inputscreen.value = string;
        }
        
        else if(buttonvalue=== "="){
            try {
                string = eval(string).toString();
                inputscreen.value = string;
            }
            catch (e) {
                inputscreen.value = "Error";
                string = "";
            }
        }
        else{
            if (string === "0") {
                string = buttonvalue;
            } else {
                string += buttonvalue;
            }
            inputscreen.value = string;
        }
        
    });
});
